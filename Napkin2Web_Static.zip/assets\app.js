import { GoogleGenerativeAI } from 'https://esm.run/@google/generative-ai';

// --- UI Elements ---
const dropZone = document.getElementById('dropZone');
const fileInput = document.getElementById('fileInput');
const filePreviewContainer = document.getElementById('filePreviewContainer');
const imagePreview = document.getElementById('imagePreview');
const pdfPlaceholder = document.getElementById('pdfPlaceholder');
const fileNameDisplay = document.getElementById('fileName');
const fileSizeDisplay = document.getElementById('fileSize');
const removeFileBtn = document.getElementById('removeFile');
const convertBtn = document.getElementById('convertBtn');
const micBtn = document.getElementById('micBtn');
const micIcon = document.getElementById('micIcon');
const transcriptionBox = document.getElementById('transcriptionBox');
const speechSection = document.getElementById('speechSection');
const previewFrame = document.getElementById('previewFrame');
const previewPlaceholder = document.getElementById('previewPlaceholder');
const loadingIndicator = document.getElementById('loadingIndicator');
const errorBox = document.getElementById('errorBox');
const downloadBtn = document.getElementById('downloadBtn');
const applyCommandBtn = document.getElementById('applyCommandBtn');
const apiKeyInput = document.getElementById('apiKeyInput');

let currentFileBase64 = null;
let currentFileType = null;
let generatedHTML = "";
let isRecording = false;
let recognition = null;

// --- Initialization ---
lucide.createIcons();

// --- File Handling ---
const handleFile = (file) => {
    if (!file) return;

    if (file.size > 15 * 1024 * 1024) {
        showError("File size exceeds 15MB. Please upload a smaller file.");
        return;
    }

    hideError();
    fileNameDisplay.textContent = file.name;
    fileSizeDisplay.textContent = (file.size / (1024 * 1024)).toFixed(2) + " MB";
    currentFileType = file.type;

    const reader = new FileReader();
    reader.onload = (e) => {
        currentFileBase64 = e.target.result;
        if (file.type.startsWith('image/')) {
            imagePreview.src = currentFileBase64;
            imagePreview.classList.remove('hidden');
            pdfPlaceholder.classList.add('hidden');
        } else {
            imagePreview.classList.add('hidden');
            pdfPlaceholder.classList.remove('hidden');
        }
        dropZone.classList.add('hidden');
        filePreviewContainer.classList.remove('hidden');
    };
    reader.readAsDataURL(file);
};

dropZone.onclick = () => fileInput.click();
fileInput.onchange = (e) => handleFile(e.target.files[0]);

dropZone.ondragover = (e) => { e.preventDefault(); dropZone.classList.add('bg-white/10'); };
dropZone.ondragleave = () => dropZone.classList.remove('bg-white/10');
dropZone.ondrop = (e) => {
    e.preventDefault();
    dropZone.classList.remove('bg-white/10');
    handleFile(e.dataTransfer.files[0]);
};

removeFileBtn.onclick = () => {
    fileInput.value = "";
    currentFileBase64 = null;
    dropZone.classList.remove('hidden');
    filePreviewContainer.classList.add('hidden');
};

// --- AI Logic ---
const getAI = () => {
    const key = apiKeyInput.value.trim();
    if (!key) {
        showError("Please enter a Gemini API Key in the header.");
        return null;
    }
    return new GoogleGenerativeAI(key);
};

const generateUI = async (isRefinement = false, instruction = "") => {
    const genAI = getAI();
    if (!genAI) return;

    loadingIndicator.classList.remove('hidden');
    hideError();
    convertBtn.disabled = true;

    try {
        const model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });
        let result;

        if (!isRefinement) {
            const prompt = `Convert this hand-drawn UI sketch into high-quality, clean, and functional HTML with Tailwind CSS. 
            Use semantic tags, modern typography (Inter), and ensure it's responsive. 
            Return ONLY the raw HTML code starting with <!DOCTYPE html>. No explanations. No markdown.`;

            const imagePart = {
                inlineData: {
                    data: currentFileBase64.split(',')[1],
                    mimeType: currentFileType
                }
            };

            result = await model.generateContent([prompt, imagePart]);
        } else {
            const prompt = `You are an expert developer. Modify the following HTML code based on this user instruction: "${instruction}".
            Current Code: 
            ${generatedHTML}
            
            Return ONLY the complete updated HTML code. No explanations. No markdown.`;
            result = await model.generateContent(prompt);
        }

        const response = await result.response;
        let htmlContent = response.text().trim();

        // Clean markdown if AI included it
        htmlContent = htmlContent.replace(/```html/g, "").replace(/```/g, "").trim();

        generatedHTML = htmlContent;
        renderPreview(htmlContent);
        speechSection.classList.remove('hidden');
        previewPlaceholder.classList.add('hidden');

    } catch (err) {
        showError("AI Error: " + err.message);
    } finally {
        loadingIndicator.classList.add('hidden');
        convertBtn.disabled = false;
    }
};

const renderPreview = (html) => {
    // Inject Tailwind CDN if missing
    let finalHtml = html;
    if (!html.includes('tailwindcss.com')) {
        const tailwindHead = '<script src="https://cdn.tailwindcss.com"></script>';
        if (html.includes('<head>')) {
            finalHtml = html.replace('<head>', `<head>${tailwindHead}`);
        } else {
            finalHtml = `${tailwindHead}\n${html}`;
        }
    }

    previewFrame.srcdoc = finalHtml;
};

convertBtn.onclick = () => generateUI();
applyCommandBtn.onclick = () => {
    const cmd = transcriptionBox.value.trim();
    if (cmd) generateUI(true, cmd);
};

// --- Speech API ---
const initSpeech = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
        showError("Voice input is currently unavailable — please use text commands.");
        return;
    }

    recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;

    recognition.onresult = (event) => {
        let transcript = "";
        for (let i = event.resultIndex; i < event.results.length; i++) {
            transcript += event.results[i][0].transcript;
        }
        transcriptionBox.value = transcript;
    };

    recognition.onstart = () => {
        isRecording = true;
        micBtn.classList.remove('mic-inactive');
        micBtn.classList.add('mic-active');
        micIcon.setAttribute('data-lucide', 'mic-off');
        lucide.createIcons();
    };

    recognition.onend = () => {
        isRecording = false;
        micBtn.classList.remove('mic-active');
        micBtn.classList.add('mic-inactive');
        micIcon.setAttribute('data-lucide', 'mic');
        lucide.createIcons();

        // Auto-apply if there's text
        const cmd = transcriptionBox.value.trim();
        if (cmd && cmd.length > 3) {
            generateUI(true, cmd);
        }
    };

    recognition.onerror = (event) => {
        showError("Speech Error: " + event.error);
        stopMic();
    };
};

const startMic = () => { if (recognition) recognition.start(); };
const stopMic = () => { if (recognition) recognition.stop(); };

micBtn.onclick = () => {
    if (!recognition) initSpeech();
    if (isRecording) stopMic(); else startMic();
};

// --- Export Logic ---
downloadBtn.onclick = async () => {
    if (!generatedHTML) return;

    const zip = new JSZip();
    zip.file("index.html", generatedHTML);

    const content = await zip.generateAsync({ type: "blob" });
    const url = URL.createObjectURL(content);
    const a = document.createElement('a');
    a.href = url;
    a.download = "napkin2web_project.zip";
    a.click();
    URL.revokeObjectURL(url);
};

// --- Helpers ---
const showError = (msg) => {
    errorBox.textContent = msg;
    errorBox.classList.remove('hidden');
    setTimeout(hideError, 8000);
};

const hideError = () => {
    errorBox.classList.add('hidden');
};

// Initialize Speech on load if possible
initSpeech();
